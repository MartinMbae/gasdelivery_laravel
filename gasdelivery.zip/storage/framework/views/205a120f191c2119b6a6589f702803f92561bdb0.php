<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <span class="card-title h4 ">Gas Companies</span>
                            <div class="float-right">
                                <button class="btn-primary" data-toggle="modal" data-target="#addCompanyModal">Add New
                                    Gas Company
                                </button>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead class=" text-primary">
                                    <tr>
                                        <th>
                                            #
                                        </th>
                                        <th>
                                            Company Name
                                        </th>

                                        <th>
                                            Action
                                        </th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php echo e($key+1); ?>

                                            </td>
                                            <td>
                                                <?php echo e($company->name); ?>

                                            </td>
                                            <td>
                                                <i class="material-icons"  data-toggle="modal" data-target="#editCompanyModal<?php echo e($company->id); ?>">edit</i>
                                            </td>
                                        </tr>

                                        <div class="modal fade" id="editCompanyModal<?php echo e($company->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                                             aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Edit Gas Company</h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <form action="<?php echo e(url('editCompany')); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <div class="modal-body">
                                                            <div class="form-group">
                                                                <label for="company_name" class="col-form-label">Company Name</label>
                                                                <input type="text" class="form-control" name="name" id="company_name" value="<?php echo e(old('name') ?? $company->name); ?>">
                                                                <input type="hidden" name="id"  value="<?php echo e($company->id); ?>">
                                                                <?php echo $errors->gas_edit->first('name', '<p class="text-danger">:message</p>'); ?>

                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                                            <button type="submit" class="btn btn-primary">Update</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="addCompanyModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add new Gas Company</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?php echo e(url('addCompany')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="company_name" class="col-form-label">Company Name</label>
                            <input type="text" class="form-control" name="name" id="company_name" value="<?php echo e(old('name')); ?>">
                            <?php echo $errors->gas->first('name', '<p class="text-danger">:message</p>'); ?>

                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Add</button>
                    </div>
                </form>
            </div>
        </div>
    </div>


    <?php if($errors->hasBag('gas')): ?>
        <script>
            $('#addCompanyModal').modal('show');
        </script>
    <?php endif; ?>

    <?php if($errors->hasBag('gas_edit')): ?>

        <script>
            $('#editCompanyModal<?php echo e(old('id')); ?>').modal('show');
        </script>
    <?php endif; ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/martin/Desktop/gasdelivery/resources/views/companies.blade.php ENDPATH**/ ?>