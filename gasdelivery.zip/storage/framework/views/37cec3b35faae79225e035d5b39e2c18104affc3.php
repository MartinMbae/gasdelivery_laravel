<footer class="footer">
    <div class="container-fluid">
        <div class="copyright float-right">
            &copy;
            <script>
                document.write(new Date().getFullYear())
            </script> <?php echo e(env('APP_NAME')); ?>

        </div>
    </div>
</footer>
<?php /**PATH /home/martin/Desktop/gasdelivery/resources/views/footer.blade.php ENDPATH**/ ?>