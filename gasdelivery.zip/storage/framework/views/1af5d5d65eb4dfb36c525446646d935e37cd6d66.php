<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <span class="card-title h4 ">Gas Cookers</span>
                            <div class="float-right">
                                <button class="btn-primary" data-toggle="modal" data-target="#addGasModal">Add New Gas
                                </button>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead class=" text-primary">
                                    <tr>
                                        <th>
                                            #
                                        </th>
                                        <th>
                                            Company
                                        </th>
                                        <th>
                                            Classification
                                        </th>
                                        <th>
                                            Weight
                                        </th>
                                        <th>
                                            Price Before Discount
                                        </th>
                                        <th>
                                            Price
                                        </th>
                                        <th>
                                            Availability
                                        </th>
                                        <th>
                                            Action
                                        </th>

                                    </tr>
                                    </thead>
                                    <tbody>

                                    <?php $__currentLoopData = $gasses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $gas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php echo e($key + $gasses->firstItem()); ?>

                                            </td>
                                            <td>
                                                <?php echo e($gas->companyName); ?>

                                            </td>
                                            <td>
                                                <?php echo e($gas->classification); ?>

                                            </td>
                                            <td>
                                                <?php echo e($gas->weight); ?> Kgs
                                            </td>
                                            <td>
                                                Ksh. <?php echo e($gas->initialPrice ?? '-'); ?>

                                            </td>
                                            <td>
                                                Ksh. <?php echo e($gas->price); ?>

                                            </td>

                                            <td>
                                                <?php echo e($gas->availability); ?>

                                            </td>
                                            <td>
                                                <i class="material-icons"  data-toggle="modal" data-target="#editGasModal<?php echo e($gas->id); ?>">edit</i>
                                            </td>
                                        </tr>
                                        <div class="modal fade" id="editGasModal<?php echo e($gas->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                                             aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Edit Gas</h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <form action="<?php echo e(url('editGas')); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <div class="modal-body">
                                                            <div class="form-group">
                                                                <input type="hidden" name="gas_id" value="<?php echo e($gas->id); ?>">
                                                                <label for="recipient-name" class="col-form-label">Gas Company:</label>
                                                                <select class="form-control" name="company_id">
                                                                    <option selected disabled>Select Gas Company</option>
                                                                    <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option
                                                                            value="<?php echo e($company->id); ?>" <?php echo e(old('company_id') == null ? ($company->id == $gas->company_id ? 'selected' : '') : (old('company_id') == $company->id ? 'selected' : '')); ?>><?php echo e($company->name); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                                <?php echo $errors->edit_gas->first('company_id', '<p class="text-danger">:message</p>'); ?>


                                                            </div>
                                                            <div class="form-group">
                                                                <label for="recipient-name" class="col-form-label">Classification</label>
                                                                <select class="form-control" name="classification">
                                                                    <option selected disabled>Select Gas Classification</option>
                                                                    <?php $__currentLoopData = $classifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option
                                                                            value="<?php echo e($classification); ?>" <?php echo e(old('classification') == null ? ($classification == $gas->classification ? 'selected' : '') : ( old('classification') == $classification ? 'selected' : '')); ?>><?php echo e($classification); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                                <?php echo $errors->edit_gas->first('classification', '<p class="text-danger">:message</p>'); ?>


                                                            </div>
                                                            <div class="form-group">
                                                                <label class="col-form-label">Weight in KGs</label>
                                                                <input class="form-control" type="number" name="weight" min="1" max="20"
                                                                       value="<?php echo e(old('weight') ?? $gas->weight); ?>" step="1" required>
                                                                <?php echo $errors->edit_gas->first('weight', '<p class="text-danger">:message</p>'); ?>


                                                            </div>

                                                            <div class="form-group">
                                                                <label class="col-form-label">Price before Discount</label>
                                                                <input class="form-control" type="number" name="initialPrice" min="100" value="<?php echo e(old('initialPrice') ?? $gas->initialPrice); ?>"
                                                                       placeholder="Leave blank if no discount">
                                                                <?php echo $errors->edit_gas->first('initialPrice', '<p class="text-danger">:message</p>'); ?>


                                                            </div>

                                                            <div class="form-group">
                                                                <label class="col-form-label">Price</label>
                                                                <input class="form-control" type="number" min="100" name="price" value="<?php echo e(old('price') ?? $gas->price); ?>">
                                                                <?php echo $errors->edit_gas->first('price', '<p class="text-danger">:message</p>'); ?>


                                                            </div>
                                                            <div class="form-group">
                                                                <label for="recipient-name" class="col-form-label">Availability</label>
                                                                <select class="form-control" name="availability">
                                                                    <option selected disabled>Select Gas Classification</option>
                                                                    <?php $__currentLoopData = $availability; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $available): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option
                                                                            value="<?php echo e($available); ?>" <?php echo e(old('availability') == null ? ($available == $gas->availability ? 'selected' : '') : ( old('availability') == $available ? 'selected' : '')); ?>><?php echo e($available); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </div>

                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                            <button type="submit" class="btn btn-primary">Submit</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="div float-right">
                                <?php echo e($gasses->links()); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="modal fade" id="addGasModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add new Gas</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?php echo e(url('addGas')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label">Gas Company:</label>
                            <select class="form-control" name="company_id">
                                <option selected disabled>Select Gas Company</option>
                                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value="<?php echo e($company->id); ?>" <?php echo e(old('company_id') == $company->id ? 'selected' : ''); ?>><?php echo e($company->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label">Classification</label>
                            <select class="form-control" name="classification">
                                <option selected disabled>Select Gas Classification</option>
                                <?php $__currentLoopData = $classifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value="<?php echo e($classification); ?>" <?php echo e(old('classification') == $classification ? 'selected' : ''); ?>><?php echo e($classification); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="col-form-label">Weight in KGs</label>
                            <input class="form-control" type="number" name="weight" min="1" max="20"
                                   value="<?php echo e(old('weight')); ?>" step="1" required>
                            <?php echo $errors->add_gas->first('weight', '<p class="text-danger">:message</p>'); ?>


                        </div>

                        <div class="form-group">
                            <label class="col-form-label">Price before Discount</label>
                            <input class="form-control" type="number" name="initialPrice" min="100" value="<?php echo e(old('initialPrice')); ?>"
                                   placeholder="Leave blank if no discount">
                            <?php echo $errors->add_gas->first('initialPrice', '<p class="text-danger">:message</p>'); ?>


                        </div>

                        <div class="form-group">
                            <label class="col-form-label">Price</label>
                            <input class="form-control" type="number" min="100" name="price" value="<?php echo e(old('price')); ?>">
                            <?php echo $errors->add_gas->first('price', '<p class="text-danger">:message</p>'); ?>

                        </div>

                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label">Availability</label>
                            <select class="form-control" name="availability">
                                <?php $__currentLoopData = $availability; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $available): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value="<?php echo e($available); ?>" <?php echo e(old('availability') == $available ? 'selected' : ''); ?>><?php echo e($available); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Add Gas</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php if($errors->hasBag('add_gas')): ?>
        <script>
            $('#addGasModal').modal('show');
        </script>
    <?php endif; ?>
    <?php if($errors->hasBag('edit_gas')): ?>
        <script>
            $('#editGasModal<?php echo e(old('gas_id')); ?>').modal('show');
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/martin/Desktop/gasdelivery/resources/views/gas.blade.php ENDPATH**/ ?>