<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h4 class="card-title ">Orders</h4>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead class=" text-primary">
                                    <tr><th>
                                            #
                                        </th>
                                        <th>
                                            Name
                                        </th>
                                        <th>
                                           Phone
                                        </th>
                                        <th>
                                            Weight
                                        </th>
                                        <th>
                                            Service
                                        </th>
                                        <td>
                                            Quantity
                                        </td>
                                        <th>
                                            Amount
                                        </th>
                                        <th>
                                           Total
                                        </th>
                                        <th>
                                            Date
                                        </th>
                                        <th>
                                            Status
                                        </th>
                                    </tr></thead>
                                    <tbody>

                                    <?php if(sizeof($latestOrders) == 0): ?>
                                        <tr>
                                            <td colspan="4">No Orders found for the selected category</td>
                                        </tr>
                                    <?php endif; ?>
                                    <?php $__currentLoopData = $latestOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $latestOrder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($key+1); ?></td>
                                            <td><?php echo e($latestOrder->user->name); ?></td>
                                            <td><?php echo e($latestOrder->user->phone); ?></td>
                                            <td><?php echo e($latestOrder->weight); ?> Kg</td>
                                            <td><?php echo e($latestOrder->classification); ?></td>
                                            <td><?php echo e($latestOrder->count); ?></td>
                                            <td><?php echo e($latestOrder->price); ?></td>
                                            <td><?php echo e((int) $latestOrder->price * (int) $latestOrder->count); ?></td>
                                            <td><?php echo e($latestOrder->date); ?></td>
                                            <td><?php echo e($latestOrder->stage); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/martin/Desktop/gasdelivery/resources/views/orders.blade.php ENDPATH**/ ?>