<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <div class="card-header card-header-warning card-header-icon">
                            <div class="card-icon">
                                <i class="material-icons">content_copy</i>
                            </div>
                            <p class="card-category">Total Users</p>
                            <h3 class="card-title"><?php echo e($usersCount); ?>

                            </h3>
                        </div>
                        <div class="card-footer">
                            <div class="stats">
                                <a href="<?php echo e(url('users')); ?>">View Users</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <div class="card-header card-header-success card-header-icon">
                            <div class="card-icon">
                                <i class="material-icons">store</i>
                            </div>
                            <p class="card-category">Complete Orders</p>
                            <h3 class="card-title"><?php echo e($completeOrders); ?></h3>
                        </div>
                        <div class="card-footer">
                            <div class="stats">
                                <a href="<?php echo e(url('orders/completed')); ?>">View Complete Orders</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <div class="card-header card-header-info card-header-icon">
                            <div class="card-icon">
                                <i class="material-icons">info_outline</i>
                            </div>
                            <p class="card-category">Ongoing Orders</p>
                            <h3 class="card-title"><?php echo e($ongoingOrders); ?></h3>
                        </div>
                        <div class="card-footer">
                            <div class="stats">
                                <a  href="<?php echo e(url('orders/ongoing')); ?>">View Ongoing Orders</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <div class="card-header card-header-danger card-header-icon">
                            <div class="card-icon">
                                <i class="material-icons">info_outline</i>
                            </div>
                            <p class="card-category">Cancelled Orders</p>
                            <h3 class="card-title"><?php echo e($cancelledOrders); ?></h3>
                        </div>
                        <div class="card-footer">
                            <div class="stats">
                                <a  href="<?php echo e(url('orders/cancelled')); ?>">View Cancelled Orders</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6 col-md-12">
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h4 class="card-title">Latest Registered Users</h4>
                            <p class="card-category">5 latest users</p>
                        </div>
                        <div class="card-body table-responsive">
                            <table class="table table-hover">
                                <thead class="text-warning">
                                <th>#</th>
                                <th>Name</th>
                                <th>Phone Number</th>
                                <th>Email</th>
                                </thead>
                                <tbody>

                                <?php $__currentLoopData = $latestUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$latestUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($key + 1); ?></td>
                                    <td><?php echo e($latestUser->name); ?></td>
                                    <td><?php echo e($latestUser->phone); ?></td>
                                    <td><?php echo e($latestUser->email); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12">
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h4 class="card-title">Latest Orders</h4>
                            <p class="card-category">5 latest orders</p>
                        </div>
                        <div class="card-body table-responsive">
                            <table class="table table-hover">
                                <thead class="text-warning">
                                <th>#</th>
                                <th>Name</th>
                                <th>Weight</th>
                                <th>Service</th>
                                <th>Status</th>
                                </thead>
                                <tbody>

                                <?php $__currentLoopData = $latestOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $latestOrder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($key+1); ?></td>
                                    <td><?php echo e($latestOrder->user->name); ?></td>
                                    <td><?php echo e($latestOrder->weight); ?> Kg</td>
                                    <td><?php echo e($latestOrder->classification); ?></td>
                                    <td><?php echo e($latestOrder->stage); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/martin/Desktop/gasdelivery/resources/views/dashboard.blade.php ENDPATH**/ ?>