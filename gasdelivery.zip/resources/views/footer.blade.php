<footer class="footer">
    <div class="container-fluid">
        <div class="copyright float-right">
            &copy;
            <script>
                document.write(new Date().getFullYear())
            </script> {{ env('APP_NAME') }}
        </div>
    </div>
</footer>
